import matplotlib.pyplot as plt
import random
import numpy as np
from sources import borrow

if __name__ == "__main__":
    x = [0,100,200,50,4,500,600,700,800,900,1000]
    x_out = x.copy()
    for j in range(0, len(x)>>1):
        x_out[2 * j + 1] -= (x[borrow(2 * j + 1 - 1, len(x))]
                             + x[borrow(2 * j + 1 + 1, len(x))]) >> 1
        x_out[2 * j] += (x_out[borrow(2 * j + 1, len(x))]
                         + x_out[borrow(2 * j - 1, len(x))]
                         + 2) >> 2
print(x_out)